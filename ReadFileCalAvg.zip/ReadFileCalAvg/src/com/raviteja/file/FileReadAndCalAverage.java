package com.raviteja.file;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;

public class FileReadAndCalAverage {

	public static void main(String[] args) throws Exception {
		ArrayList<ArrayList<String>> list1 = new ArrayList<ArrayList<String>>();
		String result1 = "", result2 = "", result3 = "";

		int count = 0;
		double sum = 0;

		try {

			BufferedReader br = new BufferedReader(new FileReader("File read and calculate average.txt"));

			String line = br.readLine();

			while (line != null) {

				System.out.println("The actual line is : " + line); //printing the actual line from the considered .txt file in the console.

				System.out.println("ArrayList is : " + Arrays.asList(line)); //printing the ArrayList which is read from the considered .txt file.
				
				System.out.println("-----------------------------------------------------------------------------------------------------------");

				list1.add(new ArrayList<String>(Arrays.asList(line))); //Adding the List1 to a new ArrayList and converting it into a Nested List

				line = br.readLine();
			}

			System.out.println("The final nested list is : " + list1); //Printing the nested list in the console.

			for (int i = 0; i < list1.size(); i++) {

				result1 = list1.get(i).get(0);	//fetching the lines from the nested list one after the other through this for loop.
				System.out.println("Result1 : " + result1); //printing the first line which is fetched from the nested list. 
				String[] words = result1.split(",");
				ArrayList<String> list11 = new ArrayList<String>(Arrays.asList(words)); //creating a new ArrayList for this first line.
				System.out.println("List11 : " + list11); //printing the ArrayList List11
				System.out.println("The value of Index-2 from the List11 : " + list11.get(2)); //fetching the start time 3:15 pm from this new ArrayList.
				
				System.out.println("-----------------------------------------------------------------------------------------------------------");
				
				result2 = (String) list11.get(2);	//fetching the start time 3:15 pm
				System.out.println("Result2 : " + result2);	//printing only 3:15 pm from the fetched part and storing it in Result2.
				String[] values = result2.split(" ");	//splitting the result 3:15 pm with spaces.  
				ArrayList<String> list12 = new ArrayList<String>(Arrays.asList(values));	//converting the result 3:15 pm into an ArrayList.
				System.out.println("List12 : " + list12);	//printing the converted ArrayList
				System.out.println("List1212 : " + list12.get(1));	//fetching the Index-1 value which is nothing but 3:15 from the above ArrayList.

				System.out.println("-----------------------------------------------------------------------------------------------------------");
				
				result3 = (String) list12.get(1);	//fetching the Index-1 value which is nothing but 3:15 from the above ArrayList.
				System.out.println("Result3 : " + result3);	//printing only 3:15 from the fetched part and storing it in Result2.
				String[] time = result3.split(":");	//splitting the colon from 3:15.
				ArrayList<String> list13 = new ArrayList<String>(Arrays.asList(time));	//converting the 3:15 into ArrayList.
				System.out.println("List13 : " + list13);	//printing the 3:15 into the converted ArrayList. 
				System.out.println("List1313 : " + list13.get(1));	//fetching Index-1 which is nothing but 15 minutes from 3:15.

				System.out.println("-----------------------------------------------------------------------------------------------------------");
				
				// The below syntax is nothing but "3 + (15/60) = 3 + 0.3 = 3.3". Converted the 15 minutes to hours as we have 3 in hours format.
				double time1 = Double.parseDouble((String) list13.get(0)) + Double.parseDouble((String) list13.get(1)) / 60;
				// System.out.println("TIME : "+time1);
				count += 1;
				sum += time1;
			}
			double average = (sum / count);
			System.out.println("Average of the start and end times for the transaction number T1234 is : " + average);	//calculating and printing the average.

			System.out.println("Actual hours of the start and end times for the transaction number T1234 is : " + ((int) average));	//from the output, average obtained is 3.2800000000000002. From this, the actual hours is nothing but the 3 --> int value.
			
			//from the output 3.2800000000000002, we need to convert the 0.28... to minutes as this is in hours. Hence, the below formula has been used.
			double min = (double) (((double) (average - ((int) average))) * 60);	 
			System.out.println("Minutes of the start and end times for the transaction number T1234 is : " + min);	//We got the minutes 16.800000000000015 after converting.

			//Considered only 16 from the obtained 16.800000000000015 minutes value.
			System.out.println("Actual Minutes of the start and end times for the transaction number T1234 is : " + ((int) min));
			
			//Converted the minutes into seconds and printed it.
			double sec = (double) (((double) (min - ((int) min))) * 60);
			System.out.println("Seconds of the start and end times for the transaction number T1234 is : " + sec);

			System.out.println("-----------------------------------------------------------------------------------------------------------");
			
			//Finally, printed the required Average time in hours:minutes:seconds.			
			System.out.println("The final required Average Time of the start and end times for the transaction number T1234 is : \n" + ((int) average) + ":" + ((int) min) + ":" + ((int) sec));

			br.close();

		} catch (Exception e) {
			System.err.println("Exception occurred.");
		}

	}

}
